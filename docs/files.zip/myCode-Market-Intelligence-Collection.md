# myCode Market Intelligence Collection
## Machine Adjacent Systems (MAS) — Last Updated March 9, 2026

---

## Purpose

This is the living market intelligence file for myCode. It collects data points, competitor intelligence, market statistics, security incidents, industry quotes, and strategic observations relevant to myCode's positioning, fundraising, and product direction. Updated continuously. Used for deck development, investor conversations, marketing, and strategic realignment.

---

## Categories

| Category | Description |
|----------|-------------|
| Market Evidence | Trends, adoption patterns, market shifts |
| Security Incident | Breaches, data loss, production failures from AI-generated code |
| Competitor | Platforms, tools, funding rounds in the vibe coding ecosystem |
| Academic Research | Studies, papers, RCTs on AI coding quality and behaviour |
| Industry Quote | Statements from leaders, CTOs, CEOs, researchers |
| Statistic | Quantitative data points with sources |
| Product/Tool | New products, features, launches relevant to myCode |
| Infrastructure | Architecture patterns, orchestration, deployment approaches |
| Token Economics | Cost structures, pricing models, token usage patterns |
| Regulatory | Government adoption, compliance, policy developments |

---

## Data Points

### DP-01: Vibe Coding Goes Mainstream, Nobody Tests
- **Date:** February 23, 2026
- **Source:** Financial Times — Oliver Roeder
- **Category:** Market Evidence
- **Finding:** FT writer built a fully functional word processor in a single weekend using AI coding tools. Called it "by some distance the best word processor I have ever used." Envisions "the atomisation of software into a mist of customised personal projects." Zero mention of testing, stress testing, edge cases, or verification anywhere in the article.
- **myCode Relevance:** Core use case. People ship AI-built software with no verification step.
- **Investor Framing:** "People are shipping AI-built software with no verification step."

### DP-02: Claude Code Creator Says Failure Modes Are Foundational Skill
- **Date:** February 22–23, 2026
- **Source:** Boris Cherny (creator of Claude Code), Lenny's Podcast
- **Category:** Industry Quote
- **Finding:** Predicted "software engineer" job title may become obsolete. Anthropic internal research: engineers shifted 70%+ of time to code review. Key statement: "Familiarity with agentic systems — including their limitations and failure modes — may become a foundational skill."
- **myCode Relevance:** The creator of AI coding tools says understanding failure is the new core skill.
- **Investor Framing:** "The creator of AI coding tools says understanding failure is the new core skill."

### DP-03: AI Assistance Degrades Debugging Skills
- **Date:** January 29, 2026
- **Source:** Anthropic Research — "How AI Assistance Impacts the Formation of Coding Skills"
- **Category:** Academic Research
- **Finding:** RCT with 52 software developers. AI users scored 17% lower on mastery assessments (nearly two letter grades). Largest gap in debugging — the exact skill required to catch AI errors. Paper states: "humans will still need the skills to catch errors, guide output, and provide oversight."
- **myCode Relevance:** AI degrades the skills needed to verify AI output. myCode removes the need for those skills.
- **Investor Framing:** "AI makes people faster but worse at catching problems."

### DP-04: IBM Falls 13% on AI Modernisation Fears
- **Date:** February 23, 2026
- **Source:** Anthropic blog post + market reaction
- **Category:** Market Evidence
- **Finding:** IBM stock fell 13% — worst single day in 25 years — after Anthropic announced AI COBOL modernisation capabilities. Legacy code migration at enterprise scale creates massive verification demand.
- **myCode Relevance:** Enterprise code migration creates verification demand. Hub71 deck evidence.
- **Investor Framing:** "Enterprise code migration at scale creates massive verification demand."

### DP-05: 91% of AI Code Gets No Human Review
- **Date:** February 22, 2026
- **Source:** Anthropic — Agent Autonomy Study
- **Category:** Statistic
- **Finding:** 91% of AI code generation steps receive no human review. Only 9% of AI-generated code gets reviewed before shipping.
- **myCode Relevance:** Direct validation — code deploys without review. myCode is the automated review.
- **Investor Framing:** "Only 9% of AI-generated code gets reviewed before shipping."

### DP-06: "True Bottleneck Is Validation"
- **Date:** February 23, 2026
- **Source:** InfoWorld — Matt Asay
- **Category:** Industry Quote
- **Finding:** "AI is not going to save developer productivity because the true bottleneck is validation, not code generation." References Charity Majors (Honeycomb CTO): can't know if code works until production under real load.
- **myCode Relevance:** Direct market thesis validation from major tech publication.
- **Investor Framing:** "Direct market thesis validation from major tech publication."
- **URL:** https://www.infoworld.com/article/4135492/ai-agents-and-bad-productivity-metrics.html

### DP-07: Dario Amodei Confirms Acceleration
- **Date:** February 2026
- **Source:** Dario Amodei interview
- **Category:** Industry Quote
- **Finding:** AI coding acceleration transforming software development. CEO of leading AI company confirms code generation speed outpacing quality.
- **myCode Relevance:** Anthropic CEO validates the generation-verification gap.

### DP-08: Regulatory Implications Emerging
- **Date:** February 2026
- **Source:** WSJ enforcement article
- **Category:** Regulatory
- **Finding:** Regulatory implications of AI-generated code in production environments.
- **myCode Relevance:** Compliance demand for verification tools growing.

### DP-09: Mainstream Media Coverage
- **Date:** February 2026
- **Source:** JPost vibe coding article
- **Category:** Market Evidence
- **Finding:** Mainstream media coverage of vibe coding phenomenon beyond tech circles.
- **myCode Relevance:** Market awareness expanding globally.

### DP-10: Employee Fired for Unverified AI Code
- **Date:** February 2026
- **Source:** NDTV
- **Category:** Market Evidence
- **Finding:** Employee terminated for submitting AI-generated code that failed in production.
- **myCode Relevance:** Real-world career consequences of unverified AI code.

### DP-11: Claude Code Has Critical CVEs
- **Date:** February 25–26, 2026
- **Source:** Check Point Research
- **Category:** Security Incident
- **Finding:** CVE-2025-59536 (CVSS 8.7): RCE via Hooks and MCP consent bypass. CVE-2026-21852 (CVSS 5.3): API key exfiltration. Attack vector: supply chain — single malicious commit compromises every developer who opens the repo.
- **myCode Relevance:** AI coding tools themselves are attack surfaces. Config files are now execution paths.
- **URL:** https://research.checkpoint.com/2026/rce-and-api-token-exfiltration-through-claude-code-project-files-cve-2025-59536/

### DP-12: Lovable Showcase App Exposes 18,697 Users
- **Date:** February 26, 2026
- **Source:** VolodsTaimi (security researcher)
- **Category:** Security Incident
- **Finding:** Lovable showcased EdTech app with 100K+ views. Security researcher found 16 vulnerabilities (6 critical) in hours. Auth logic inverted — blocked logged-in users, let anonymous ones through. 18,697 user records exposed. Account deletion, grade modification, bulk email — all unauthenticated. Lovable closed the support ticket without fixing.
- **myCode Relevance:** Behavioural bug (inverted auth) that linters and static analysis cannot catch. myCode's territory.
- **Investor Framing:** "$6.6B platform showcased app had backwards auth exposing 18,697 users. Platform closed the bug report."

### DP-13: 2,000+ Vulnerabilities Across 5,600 Vibe-Coded Apps
- **Date:** October 2025
- **Source:** Escape.tech
- **Category:** Statistic
- **Finding:** 5,600 publicly available vibe-coded apps scanned across Lovable (~4,000), Base44, Create.xyz, Vibe Studio, Bolt.new. 2,000+ vulnerabilities, 400+ exposed secrets, 175 PII instances (medical records, IBANs, phone numbers). CVE-2025-48757: RLS bypass via public API keys.
- **myCode Relevance:** Quantitative evidence of the problem at scale.
- **Investor Framing:** "Researchers scanned 5,600 vibe-coded apps. Found 2,000+ vulnerabilities, 400+ exposed secrets, 175 PII leaks. This is the lower bound."
- **URL:** https://escape.tech/blog/methodology-how-we-discovered-vulnerabilities-apps-built-with-vibe-coding/

### DP-14: Karpathy Retires "Vibe Coding" for "Agentic Engineering"
- **Date:** February 26, 2026
- **Source:** The New Stack
- **Category:** Market Evidence
- **Finding:** Karpathy wants to retire "vibe coding" in favour of "agentic engineering." Forrester predicted this shift in Q4 2024. Caylent CTO: "The differentiator isn't which LLM you picked, it's the agentic harness — tools, context management, evaluation, observability infrastructure."
- **myCode Relevance:** Market maturing. Verification is the explicit gap as the practice professionalises.
- **Investor Framing:** "Industry leaders now explicitly say the bottleneck is verification, not generation."

### DP-15: Global Vibe Coding Search Data
- **Date:** February 5, 2026
- **Source:** LeadsNavi via The New Stack
- **Category:** Statistic
- **Finding:** Google search data for "vibe coding" across 24 countries. Top 5 by volume per 100K: Switzerland (41.19), Germany (40.29), Canada (37.78), Sweden (35.04), Finland (34.69). Europe dominates top 10. US ranks 15th (26.78). Middle East completely unmapped (study excluded region).
- **myCode Relevance:** Global demand. Middle East is white space. Hub71 positioning as first mover.

### DP-16: Anthropic Finds 500+ Zero-Days via AI
- **Date:** February 24, 2026
- **Source:** VentureBeat
- **Category:** Product/Tool
- **Finding:** Claude Opus 4.6 found 500+ high-severity zero-day vulnerabilities in production open-source codebases. Bugs survived decades of expert review. Launched Claude Code Security (Enterprise/Team). CrowdStrike fell ~8%, Cloudflare >8%.
- **myCode Relevance:** Complementary: Claude Code Security finds security vulnerabilities through reasoning. myCode finds reliability vulnerabilities through stress testing. Same thesis, different attack surface.
- **Investor Framing:** "Anthropic validated AI can find what traditional tools miss. They do security. We do reliability."

### DP-17: US Military Adopts AI Coding — No Verification
- **Date:** February 26, 2026
- **Source:** DefenseScoop
- **Category:** Regulatory
- **Finding:** CDAO + Army seeking AI coding tools for tens of thousands of developers. IDE and CLI-based agentic coders, deployable at edge and air-gapped. FedRAMP High + IL5 required. Attribution/traceability required. No verification layer mentioned.
- **myCode Relevance:** Government mandating generation with no verification. myCode runs --offline with zero API calls. Air-gapped readiness.

### DP-18: Columbia University Confirms Agents Optimise for Speed Over Safety
- **Date:** February 22, 2026
- **Source:** Columbia University / Towards Data Science
- **Category:** Academic Research
- **Finding:** Coding agents have 3 systematic failure patterns: speed over safety, unaware of side effects, pattern matching not judgment. Moltbook case: 1.5M API keys and 35K emails exposed via misconfigured Supabase. Author: "Coding agents optimize for making code run, not making code safe."
- **myCode Relevance:** Academic validation. Columbia recommends automated guardrails — that's myCode.
- **URL:** https://towardsdatascience.com/the-reality-of-vibe-coding-ai-agents-and-the-security-debt-crisis/

### DP-19: XDA Developer Tests ChatGPT Code — Scary Vulnerabilities
- **Date:** September 5, 2025
- **Source:** XDA Developers
- **Category:** Security Incident
- **Finding:** Experienced developer generated code in C++, Python, Java via ChatGPT. Even the most basic applications had vulnerabilities. Individual vulns are bad but compound as more are added. Published GitHub repo with all code samples. His conclusion: "code generated by LLMs is fine if the user understands programming — but people use these tools as a replacement for knowledge."
- **myCode Relevance:** Practitioner demonstration with reproducible examples on GitHub. Potential target for myCode demo.
- **URL:** https://www.xda-developers.com/tried-vibe-coding-chatgpt-vulnerabilities/

### DP-20: Georgetown — 45% of AI Code Has Security Vulnerabilities
- **Date:** March 2026
- **Source:** Georgetown CSET study (via DEV Community)
- **Category:** Statistic
- **Finding:** 45% of AI-generated code contains security vulnerabilities. 86% failed XSS defence. 88% vulnerable to log injection. 47% contained SQL injection flaws. GitHub Copilot suggestion acceptance rate: ~30% (developers reject 70%).
- **myCode Relevance:** Nearly half of all AI-generated code has real, exploitable vulnerabilities.

### DP-21: "Vibe Coding Is Dead" — Shift to Specification-First
- **Date:** March 2026
- **Source:** DEV Community
- **Category:** Market Evidence
- **Finding:** Market shifting from suggestion-first tools (Copilot, Cursor, ChatGPT) to specification-first platforms. Georgetown: security-focused prompts improved secure code generation from 56% to 66%. "If your AI-generated application doesn't have automated tests, it doesn't ship. Period."
- **myCode Relevance:** Market demanding verification as standard practice. myCode is verification-first.
- **URL:** https://dev.to/michelle-jones/vibe-coding-is-dead-heres-what-replaced-it-4472

### DP-22: 25% of YC Startups Are 95% AI-Generated
- **Date:** February 2026
- **Source:** Kristin Darrow — State of Vibecoding Feb 2026
- **Category:** Statistic
- **Finding:** 25% of YC Winter 2025 startups reported codebases that were 95% AI-generated. 84% of developers use or plan to use AI tools. AI co-authored PRs showed 2.74x higher rates of security vulnerabilities.
- **myCode Relevance:** Quarter of YC startups are almost entirely AI-coded. Massive addressable market.
- **URL:** https://www.kristindarrow.com/insights/the-state-of-vibecoding-in-feb-2026

### DP-23: Security CEO Predicts "Catastrophic Explosions"
- **Date:** January 20, 2026
- **Source:** The New Stack — David Mytton (Arcjet CEO)
- **Category:** Industry Quote
- **Finding:** "In 2026, I expect more and more vibe-coded applications hitting production. There will be big explosions." Eitan Worcel (Mobb CEO): "Your backlog is no longer static debt; it is active risk that influences every new line of code."
- **myCode Relevance:** Security experts predicting exactly what myCode is built to prevent.
- **URL:** https://thenewstack.io/vibe-coding-could-cause-catastrophic-explosions-in-2026/

### DP-24: Claude Code Deletes Production Database
- **Date:** March 7, 2026
- **Source:** Tom's Hardware
- **Category:** Security Incident
- **Finding:** Developer had Claude Code run Terraform commands with wide permissions. Missing state file caused Terraform destroy on production. Two websites wiped including database with 2.5 years of records and backup snapshots. AWS Business support restored data next day.
- **myCode Relevance:** Different class from myCode's problem (agent behaviour vs code reliability) but same root cause: over-reliance on AI without verification. myCode's Docker containerisation and read-only mounts prevent this class of failure for testing.
- **URL:** https://www.tomshardware.com/tech-industry/artificial-intelligence/claude-code-deletes-developers-production-setup-including-its-database-and-snapshots-2-5-years-of-records-were-nuked-in-an-instant

### DP-25: Nested Claude Code + Tmux for Parallel Development
- **Date:** March 3, 2026
- **Source:** Geeky Gadgets / All About AI
- **Category:** Infrastructure
- **Finding:** Central controller coordinates multiple Tmux terminals for parallel Claude Code task execution. Dynamic task allocation based on complexity. Demonstrated with 3JS galaxy (6 terminals) and micro GPT training (4 terminals).
- **myCode Relevance:** Multi-agent orchestration pattern. As parallel agent development scales, verification at each merge point becomes critical.
- **URL:** https://www.geeky-gadgets.com/nested-claude-code-tmux/

### DP-26: Chamath's 8090 — $10M/Year in AI Costs
- **Date:** March 7, 2026
- **Source:** Business Insider / All-In Podcast
- **Category:** Token Economics
- **Finding:** Chamath Palihapitiya's startup 8090 (goal: replace legacy software with AI) trending toward $10M/year in AI costs. Costs tripled since November 2025. Migrating off Cursor to Claude Code for cost savings. "Ralph Wiggum loops" — retry prompts that never solve + cost fortune. "My costs are going up 3X every three months. My revenues are not."
- **myCode Relevance:** Validates minimal-LLM architecture (Gemini Flash free tier, offline mode, template scenarios). 8090 is a potential customer — generating enterprise software at scale with no verification layer.
- **Investor Framing:** "Even billionaire-funded startups struggling with AI costs. Verification must be cost-efficient."

### DP-27: Emergent — $70M Raise, 30K+ K8s Pods, $50M ARR
- **Date:** March 2026
- **Source:** Emergent.sh blog / Experiment.com review
- **Category:** Competitor
- **Finding:** Full-stack vibe coding platform. $70M Series B (Khosla Ventures, SoftBank). $50M ARR. Runs 30K+ Kubernetes pods for isolated development environments. Multi-agent architecture: Architect, Developer, QA, DevOps, Optimizer agents. QA agent checks CRUD functionality, not runtime robustness.
- **myCode Relevance:** Emergent is a customer, not competitor. Their QA agent checks functionality, not survivability. myCode fills the gap. K8s architecture informs enterprise execution layer.
- **Investor Framing:** "$70M funded platform generating 30K+ apps. Their QA checks functionality, not survivability."
- **URL:** https://emergent.sh/blog/real-environments-for-ai-agents-and-why-we-bet-on-kubernetes

### DP-28: Moltbook — 1.5M API Keys Exposed
- **Date:** 2026
- **Source:** Wiz security report (via TDS)
- **Category:** Security Incident
- **Finding:** AI agent social network built entirely via vibe coding. Misconfigured Supabase database exposed 1.5M API keys and 35K user email addresses. Root cause: vibe coding — developers built fast, took shortcuts, missed critical security configuration.
- **myCode Relevance:** High-profile incident demonstrating that AI agents optimise for making code run, not making it safe.

### DP-29: Cursor — $2B ARR
- **Date:** February–March 2026
- **Source:** Multiple sources
- **Category:** Competitor
- **Finding:** Cursor reached $2B ARR, doubled in 3 months. 60% enterprise revenue. Launched "Automations" (Bugbot). Complementary to myCode — Cursor generates, myCode verifies.
- **myCode Relevance:** $2B ARR proves the code generation market is massive. No built-in verification layer.

### DP-30: Claude Marketplace Launch
- **Date:** March 2026
- **Source:** Anthropic
- **Category:** Product/Tool
- **Finding:** Claude Marketplace launched. Lovable is a partner. Future distribution channel for myCode enterprise tier.
- **myCode Relevance:** Potential distribution channel for enterprise myCode integration.

### DP-31: Gas Town — "Kubernetes for AI Coding Agents"
- **Date:** March 2026
- **Source:** Cloud Native Now
- **Category:** Infrastructure
- **Finding:** Steve Yegge (40+ years at Amazon, Google, Sourcegraph) built Gas Town — open-source orchestration for 20-30 Claude Code instances in parallel. 7 specialised roles (Mayor, Polecats, Refinery, Witness, Deacon, Dogs, Crew). Git-backed state. "Kubernetes asks 'Is it running?' Gas Town asks 'Is it done?'"
- **myCode Relevance:** Multi-agent development pattern. As agent swarms scale, verification at each merge point becomes critical. More agents = more unverified code.
- **URL:** https://cloudnativenow.com/features/gas-town-what-kubernetes-for-ai-coding-agents-actually-looks-like/

### DP-32: AWS Outages Caused by AI Coding Bot
- **Date:** March 2026
- **Source:** Tom's Hardware
- **Category:** Security Incident
- **Finding:** Multiple AWS outages reportedly caused by AI coding bot blunder. Amazon attributed to "user error."
- **myCode Relevance:** AI agents causing production infrastructure failures at hyperscaler level.

### DP-33: Cowork Launch — 11GB Files Deleted
- **Date:** March 2026
- **Source:** Multiple sources
- **Category:** Security Incident
- **Finding:** Anthropic Cowork launch: user lost 11GB of files to AI agent performing destructive file operations.
- **myCode Relevance:** Recurring pattern in 2026: AI agents destroying user data without adequate verification.

---

## Key Statistics Summary

| Statistic | Source | Value |
|-----------|--------|-------|
| AI code with no human review | Anthropic | 91% |
| AI-generated code with security vulns | Georgetown CSET | 45% |
| XSS defence failure rate | Georgetown CSET | 86% |
| YC startups 95% AI-generated | Kristin Darrow | 25% |
| AI co-authored PR vuln rate multiplier | Kristin Darrow | 2.74x |
| Developers using AI tools | Industry surveys | 84% |
| Copilot suggestion rejection rate | Georgetown CSET | 70% |
| Vibe-coded apps scanned with vulns | Escape.tech | 2,000+ across 5,600 |
| Skills degradation from AI assistance | Anthropic | 17% lower |
| Cursor ARR | Multiple | $2B |
| Emergent funding | Khosla/SoftBank | $70M |
| Emergent ARR | Experiment.com | $50M |

---

## Recurring Themes

1. **Generation outpaces verification.** Every data point confirms this. The bottleneck shifted from writing code to knowing if code works.

2. **Security is the visible symptom, reliability is the hidden one.** Security breaches make headlines. Silent performance degradation doesn't — until production fails.

3. **AI agents are destructive without guardrails.** Production database deletions, file losses, AWS outages. Verification cannot be optional.

4. **The market is professionalising.** Karpathy's "agentic engineering" shift. Specification-first platforms replacing suggestion-first tools. Verification becoming expected.

5. **Multi-agent development amplifies the problem.** Gas Town, Nested CC, Emergent's multi-agent architecture. More agents = more unverified code = larger verification gap.

6. **Cost pressure favours efficient verification.** Chamath's $10M AI costs. Minimal-LLM architectures (like myCode's) are a competitive advantage.

---

## myCode Positioning Lines

- "Semgrep tells you your code is secure. myCode tells you your code survives Monday morning."
- "Runtime failure intelligence for AI-generated software."
- "You're spending $10M on AI to generate code. How much are you spending to verify it works?"
- "45% of AI-generated code has security vulnerabilities. What percentage has reliability vulnerabilities? Nobody knows. That's the problem."
- "25% of YC startups are 95% AI-generated. All of them need verification. None of them have it."

---

*Machine Adjacent Systems (MAS) — ADGM, Abu Dhabi*
*This document is continuously updated. Add new data points at the end with the next sequential DP number.*
